class Spiller {
  constructor() {
    this.x = 300;
    this.y = height - 10;
    this.bredde = 60;
    this.høyde = 10;
    this.xret = 0; //Retning x akse
    
  }
  
  vis(){
    fill(0, 255, 0)
    noStroke();
    rect(this.x, this.y, this.bredde, this.høyde);
    rect(this.x + 20, this.y -10, 20, 10)
  }
  
  bevegelse(){
    this.x += this.xret * 10;
  }
  
  setRet(ret){
    this.xret = ret;
  }
  
}