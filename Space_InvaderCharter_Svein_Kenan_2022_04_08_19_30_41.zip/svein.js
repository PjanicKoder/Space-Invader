 class Svein{
  constructor(x, y, bildeA, bildeB, poengSum) {
   this.x = x;
   this.y = y;
   this.bredde = 38;
   this.høyde = 26;
   this.lever = true;
   this.bildeA = bildeA
   this.bildeB = bildeB
   this.nåBilde = "A";
   this.poeng = poengSum;
   this.radius = 20; //bare for kollisjon
   this.xret = 1; 
  }
 
   
  vis(){
    if (this.lever) {  //viser bare hvis lever
      if (this.nåBilde === "A") {
        image(this.bildeB, this.x, this.y, this.bredde, this.høyde);
      }
      if (this.nåBilde === "B") {
        image(this.bildeA, this.x, this.y, this.bredde, this.høyde);
      }
    }
  }
  
  
   bevegelse() {
    this.x = this.x + this.xret;
    
    
    //bilde animasjon
    if (this.nåBilde === "A") {
      this.nåBilde = "B";
    } else if (this.nåBilde === "B") {
      this.nåBilde = "A";
    }
  } 
  
   
   
   //Beveger sveins nedover
   bevegelseNed(){
     this.xret = -this.xret;
     this.y = this.y + this.høyde;
   }
  
   
   
}