/* Space Invaders
 * av Kenan Tursic
 */


let spiller;
let sveins = []; //array med sveins
let vaksiner = []; //array med vaksiner
let poeng = 0;

function preload(){
  //Laster inn bilder som jeg bruker
  svein1a = loadImage("bilder/svein1a.png");
  svein1b = loadImage("bilder/svein1b.png");
  svein2a = loadImage("bilder/svein2a.png");
  svein2b = loadImage("bilder/svein2b.png");
  
  //Laster inn lyder som jeg bruker
  TreffLyd = loadSound("lyder/treff.wav");
  VinnLyd = loadSound("lyder/VinnLyd.wav");
}

function setup() {
  createCanvas(600, 400);
  frameRate(10); //Framerate satt til 10 for å gi retro vibe
  imageMode(CENTER);
  
  spiller = new Spiller();
  
  
  //Lage nederste rad med sveins
  let startX = 80;
  let startY = 80;
  for (var i = 0; i < 6; i++){
    sveins[i] = new Svein(i * startX + 80, startY, svein1a, svein1b, 5);
  }
  
  
  //Lage øverste rad med sveins
  startY = 40;
  let offset = 0;
  for (var j = 6; j < 12; j++){
    sveins[j] = new Svein(offset * startX + 80, startY, svein2a, svein2b, 10);
    offset++;
  }

  
  
}

function draw() {
  background(50);
  spiller.vis();
  spiller.bevegelse();
  
  //viser og beveger Sveins. ++Setter kant
  var kant = false;
  for (var i = 0; i < sveins.length; i++){
    sveins[i].vis();
    sveins[i].bevegelse();
    if (sveins[i].x > width || sveins[i].x < 0){
      kant = true;
    }  
  }  
  //setter kant
  if (kant) {
      for (var k = 0; k < sveins.length; k++){
        sveins[k].bevegelseNed();
      }
    }
  
  
  //vise og bevege vaksiner
  for (var las = 0; las < vaksiner.length; las++) {
    vaksiner[las].vis();
    vaksiner[las].bevegelse();
    
    
    //for kollisjon mellom vaksiner og svein
    for (var j = 0; j < sveins.length; j++) {
      if (vaksiner[las].treffer(sveins[j])) {
        vaksiner[las].fjern();
        poeng = poeng + sveins[j].poeng;
        sveins.splice(j, 1); //fjerner svein fra array
        TreffLyd.play()
    }
   } //slutten av svein loop
  } //slutten av vaksiner loop #1
  
  //loop av vaksiner; fjerner vaksinene
  for (var z = vaksiner.length - 1; z >= 0; z--){
    if (vaksiner[z].slette) {
      vaksiner.splice(z, 1) //fjerner vaksiner fra array
      
    }
    
  } //slutten av vaksine loop #2
  
  oppdater();
  
  //sjekker om spillet er over
  if (sveins.length <= 0){
    gameOver();
  }
  
}//slutten av draw function


//knapper
function keyReleased() {
  spiller.setRet(0);
}

function keyPressed() {
  if (key === " "){
    var vaksine = new Vaksine(spiller.x + (spiller.bredde / 2), spiller.y);
    vaksiner.push(vaksine);
  }
  if (keyCode === RIGHT_ARROW) {
    spiller.setRet(1);
  } else if (keyCode === LEFT_ARROW) {
    spiller.setRet(-1);
  }
}

function oppdater() {
  fill(255);
  text("Poeng: " + poeng, 10, 20);
  text("Charter-Svein Igjen: " + sveins.length, 70, 20);
}

//Skjerm når du vinner
function gameOver() {
  background(0);
  textSize(25);
  textAlign(CENTER);
  text("CHARTER SVEIN ER NÅ FULL VAKSINERT!", width / 2, height / 2);
  
  VinnLyd.play()
  noLoop();
 
}