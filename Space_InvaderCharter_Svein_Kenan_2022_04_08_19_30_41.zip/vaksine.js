class Vaksine {
  constructor(x, y){
    this.x = x;
    this.y = y;
    this.bredde = 5;
    this.høyde = 25;
    this.r = 5; //dette er radius
    this.diam = this.r * 2; //detter er diameter
    this.slette = false; 
    
  }
  
  vis(){
    noStroke();
    fill(255); 
    rect(this.x, this.y, this.bredde, this.høyde);
    rect(this.x -5, this.y + 15, 15, 2);
    rect(this.x + 1, this.y - 10, 3, 10);
    
    
  }
  
  bevegelse(){
    this.y = this.y - 20; //Beveger laseren oppover y aksen
  }
  
  
  treffer(svein) {
    // distanse funkjsonen måler distansen mellom to steder
    var d = dist(this.x, this.y, svein.x, svein.y); 
    if (d < this.r + svein.radius){
      return true; //returnerer en verdi, nå true eller false
    } else{
      return false;
    }
  } 
  
  fjern(){
    this.slette = true;
  }
}